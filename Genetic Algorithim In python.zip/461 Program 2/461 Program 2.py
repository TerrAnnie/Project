
#TerrAnnie Scott
#CS461
#Note fitnessScoreOverall index = tempStoragelist Index which is why this works 
import random
import math



Faculty = [ "Gharibi", "Gladbach", "Hare", "Nait-Abdesselam", "Shah", "Song", "Uddin", "Xu", "Zaman", "Zein el Din"]

classes = [{
    "course" : "CS101A",
    "expected enrollment" : 50,
    "preferred instructors": ["Gladbach","Gharibi", "Hare", "Zein el Din"],
    "other instructors" : ["Zaman", "Nait-Abdesselam"]
    }
           ,
    {
    "course" : "CS101B",
    "expected enrollment" : 50,
    "preferred instructors": ["Gladbach","Gharibi", "Hare", "Zein el Din"],
    "other instructors" : ["Zaman", "Nait-Abdesselam"]
    }
           ,
    {
    "course" : "CS191A",
    "expected enrollment" : 50,
    "preferred instructors": ["Gladbach","Gharibi", "Hare", "Zein el Din"],
    "other instructors" : ["Zaman", "Nait-Abdesselam"]
    }
           ,
    {
    "course" : "CS191B",
    "expected enrollment" : 50,
    "preferred instructors": ["Gladbach","Gharibi", "Hare", "Zein el Din"],
    "other instructors" : ["Zaman", "Nait-Abdesselam"]
    }
           ,
    {
    "course" : "CS201",
    "expected enrollment" : 50,
    "preferred instructors": ["Gladbach","Shah", "Hare", "Zein el Din"],
    "other instructors" : ["Zaman", "Nait-Abdesselam", "Song"]
    }
           ,
    {
    "course" : "CS291",
    "expected enrollment" : 50,
    "preferred instructors": ["Song","Gharibi", "Hare", "Zein el Din"],
    "other instructors" : ["Zaman", "Nait-Abdesselam", "Shah", "Xu"]
    }
           ,
     {
    "course" : "CS303",
    "expected enrollment" : 60,
    "preferred instructors": ["Gladbach", "Hare", "Zein el Din"],
    "other instructors" : ["Zaman", "Song", "Shah"]
    }
           ,
     {
    "course" : "CS304",
    "expected enrollment" : 25,
    "preferred instructors": ["Xu","Gladbach", "Hare"],
    "other instructors" : ["Zaman", "Nait-Abdesselam", "Shah", "Song", "Uddin", "Zein el Din"]
    }
           ,
     {
    "course" : "CS394",
    "expected enrollment" : 20,
    "preferred instructors": ["Song","Xu"],
    "other instructors" : ["Nait-Abdesselam","Zein el Din"]
    }
           ,
    {
    "course" : "CS449",
    "expected enrollment" : 60,
    "preferred instructors": ["Song","Xu", "Shah"],
    "other instructors" : ["Uddin","Zein el Din"]
    }
           ,
    {
    "course" : "CS451",
    "expected enrollment" : 100,
    "preferred instructors": ["Song","Xu", "Shah"],
    "other instructors" : ["Nait-Abdesselam","Zein el Din", "Hare"]
    }

]

rooms = [ #9 elements
    {
    "building":"Katz",
    "number" : "3",
    "capacity": 45
    }
    ,
     {
    "building":"FH",
    "number" : "216",
    "capacity": 30
    }
    ,
     {
    "building":"Royall",
    "number" : "206",
    "capacity": 75
    }
    ,
     {
    "building":"Royall",
    "number" : "201",
    "capacity": 50
    }
    ,
     {
    "building":"FH",
    "number" : "310",
    "capacity": 108
    }
    ,
    {
    "building":"Haag",
    "number" : "201",
    "capacity": 60
    }
    ,

{
    "building":"Haag",
    "number" : "301",
    "capacity": 75
    }
    ,
    {
    "building":"MNLC",
    "number" : "325",
    "capacity": 450
    }
    ,
    {
    "building":"Bloch",
    "number" : "119",
    "capacity": 60
    }
    
    ]

classTimes = [ "10AM", "11AM", "12PM", "1PM", "2PM", "3PM"]



tempStorageList = []
newGeneration= []


Parents = []



def averageFitness(lst):#calculate avg fitness
    x= lst
    total = AddList(x)
    
   
    average = total/500
   

    return average
    
def softMax ():#performs softmax
    total = 0
    
 
    for i in range(0,len(fitnessScoresOverall)):
        fitnessScoresOverall[i] = math.exp(fitnessScoresOverall[i])
    total = AddList(fitnessScoresOverall)
    
    for i in range (0,len(fitnessScoresOverall)):
        fitnessScoresOverall[i] = round(fitnessScoresOverall[i]/total,2)
        
        
    

def AddList (lst):#adds list to get a total
    sum = 0
    for i in range (0, len(lst)):
        sum += lst[i]
    return sum

def findMaxFitness ():#finds greatest and returns this index
    maxIndex = 0
    
    for i in range(0,500):
        if fitnessScoresOverall[i] > fitnessScoresOverall[maxIndex]:
            maxIndex = i
    return maxIndex
            
    
def Tournament_Selection(placeHolder,mutateValue):#PlaceHolder= place we are inserting into the list
    
    Index1 = -1
    Index2= -1
    Index3 = -1
    MaxIndex = 0
    prevMaxIndex = 0
    i=0
    Assign1 = False
    Assign2 = False
    
    choosenParent1 = {}
    choosenParent2 = {}
    #Tournament Selection take 3 chromosomes find which one is the best do this twice so we can do a crossOver
    while i < 2:
        
        while True:
            
            randIndex = random.randint(0,499)#make sure to change later
            if randIndex != Index1 and randIndex != Index2:
                if Assign1 == False:#this one will always go first no matter what
                   
                    Index1=randIndex
                    Assign1 =True
                elif Assign2 == False:
                    Index2=randIndex
                    Assign2 = True
                else:
                    Index3 = randIndex
                    break
            else:
                continue
        
        maxFitness = fitnessScoresOverall [Index1]
        MaxIndex = Index1
        if maxFitness < fitnessScoresOverall [Index2]:#if Maxfitness is greater here than it's the parent we use
            MaxIndex = Index2
        if maxFitness < fitnessScoresOverall [Index3]:
            MaxIndex = Index3

        if i == 0:
            
            choosenParent1 = tempStorageList[MaxIndex]#fitnessSCore index correlates with TempStorage index
            
            Index1 = -1
            Index2= -1
            Index3 = -1
            Assign1 = False
            Assign2 = False
            i +=1
            prevMaxIndex = MaxIndex
            continue
        if i == 1:
            if MaxIndex == prevMaxIndex:
                Index1 = -1
                Index2= -1
                Index3 = -1
                Assign1 = False
                Assign2 = False
            
                continue #try the algorithim again if indexes are equal
            else:
                choosenParent2 = tempStorageList[MaxIndex]
                i+=1
                Index1 = -1
                Index2= -1
                Index3 = -1
                Assign1 = False
                Assign2 = False
               
            
        tempList= [MaxIndex,prevMaxIndex]
        tempList2 = [prevMaxIndex, MaxIndex]
        
    
        
        if tempList not in Parents and tempList2 not in Parents:
            crossover(MaxIndex,prevMaxIndex,placeHolder,mutateValue)
            Parents.append([MaxIndex, prevMaxIndex])
            Parents.append([prevMaxIndex,MaxIndex])
           
            
            
            break
        else: #if the parents are already in the list we need to go back up and try again
            i = 0
            
           
            continue
            
            
                    
        
            
    
        
    



def lstFind (lst, x):#find in list return index
    for i in range (0, len(lst)):
        if lst[i] == x:
            return i;
        
def crossover(index1, index2,placeHolderIndex, mutateVal):#used to crossover the parents
    crossOverVal = random.randint (0,9)

    for i in range (0,11):
        if i <= crossOverVal:
            newGeneration[placeHolderIndex][i] = tempStorageList[index1][i] #get the first elements at crossover of first parent
            newGeneration[placeHolderIndex +1][i] = tempStorageList[index2][i]#get the first elements at crossover of second parent 
        else:
            newGeneration[placeHolderIndex][i] = tempStorageList[index2][i] #get second group of elements from parent 2
            newGeneration[placeHolderIndex +1][i] = tempStorageList[index1][i]#get second group of elements from parent 1
            
    #make mutation happen here
    randVal = random.randint(1,mutateVal)#if mutation happens change everything except course name
    if(randVal == 1):
        randIndex = random.randint(0,10)
        randBuilding= random.randint(0,8)
        randInstruct=random.randint(0,9)
        randTime = random.randint(0,5)
        course = newGeneration[placeHolderIndex][randIndex].get("course")
        tempDic = {"course" : course, "building" : rooms[randBuilding].get("building"), "room" : rooms[randBuilding].get("number"), "instructor" : Faculty[randInstruct], "time" : classTimes[randTime]}
        newGeneration[placeHolderIndex][randIndex] = tempDic 
            

    
            
    

    
def fitnessFunction(currN,currClass):#currNCurrent Place in N in generation CurrClass = class in schedule 
    fitnessScore = 0;
    capacity = 0
    building= tempStorageList [currN][currClass].get("building")
    buildingNum = tempStorageList [currN][currClass].get("room")
    time = tempStorageList [currN][currClass].get("time")
    course = tempStorageList [currN][currClass].get("course")
    intstructor = tempStorageList [currN][currClass].get("instructor")
    tempInstructorList = []
    tempOtherIntructorList = []
    instructorCount = 1 #instructor is teaching at least once course
    doubleBookedFlag = False #professor teaching more than one class at a time
    for i in range (0,11):#Test Course Spefic Functions and Sees if i
        if i == currClass: #dont check where we currently are 
            continue
        else:
            #print(tempStorageList[currN][i])
            tempTime = tempStorageList[currN][i].get("time")
            tempBuilding = tempStorageList[currN][i].get("building")
            tempBuildingNum= tempStorageList[currN][i].get("room")
            tempInstructor = tempStorageList[currN][i].get("instructor")
            tempCourse = tempStorageList[currN][i].get("course")
            if building==tempBuilding and tempTime == time and tempBuildingNum == buildingNum: #check if same building
               
                
                fitnessScore -= 0.5

            if (course == "CS101A" or course == "CS101B") and (tempCourse == "CS101A" or tempCourse == "CS101B"):#check if same time and 5 hours apart 
                if tempTime == time:
                    fitnessScore -=0.5
                   
                    
                elif (tempTime == "3PM" and time == "10AM") or (tempTime == "10AM" and time == "3PM"):
                    fitnessScore += 0.5
                   
               

            if (course == "CS191A" or course == "CS191B") and (tempCourse == "CS191A" or tempCourse == "CS191B"):
                if tempTime == time:
                    fitnessScore -=0.5
                elif (tempTime == "3PM" and time == "10AM") or (tempTime == "10AM" and time == "3PM"):
                    fitnessScore += 0.5

            if (course == "CS191A" or course == "CS191B") and (tempCourse == "CS101A" or tempCourse == "CS101B"):#Course specific check to see if times are equal and consecutive between 191 and 101
                     
                if tempTime == time:
                    fitnessScore -=0.25
                else:
                    if time != "2PM" and time != "3PM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes[index +2]:
                            fitnessScore += 0.25
                            
                    if time != "10AM" and time!= "11AM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes[index -2]:
                            fitnessScore += 0.25
                   
                   

                    if time!= "10AM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes [index -1]:
                            if(tempBuilding == "Katz" and building == "Bloch") or (tempBuilding == "Bloch" and building == "Katz"):
                                fitnessScore -=0.4
                            else:
                                fitnessScore += 0.5
                    if time!= "3PM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes [index +1]:
                            if(tempBuilding == "Katz" and building == "Bloch") or (tempBuilding == "Bloch" and building == "Katz"):
                                fitnessScore -=0.4
                            else:
                                fitnessScore += 0.5
                    
            if (course == "CS101A" or course == "CS101B") and (tempCourse == "CS191A" or tempCourse == "CS191B"):
                if tempTime == time:
                    fitnessScore -=0.25
                else:
                    if time != "2PM" and time != "3PM":#check if more than one hour apart 
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes[index +2]:
                            fitnessScore += 0.25
                            
                    if time != "10AM" and time!= "11AM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes[index -2]:
                            fitnessScore += 0.25
                   
                   

                    if time!= "10AM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes [index -1]:
                            if(tempBuilding == "Katz" and building == "Bloch") or (tempBuilding == "Bloch" and building == "Katz"):
                                fitnessScore -=0.4
                            else:
                                fitnessScore += 0.5
                    if time!= "3PM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes [index +1]:
                            if(tempBuilding == "Katz" and building == "Bloch") or (tempBuilding == "Bloch" and building == "Katz"):
                                fitnessScore -=0.4
                            else:
                                fitnessScore += 0.5
               
                    

            if tempTime == time and tempInstructor == intstructor: #checking to see if instructor is teaching another course at the same time 
                fitnessScore -= 0.2
                instructorCount +=1;
               
                doubleBookedFlag = True
            
                
            elif tempInstructor == intstructor: #same instructor check if consecutive if not then 
                instructorCount +=1
                if time!= "10AM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes [index -1]:
                            if(tempBuilding == "Katz" and building == "Bloch") or (tempBuilding == "Bloch" and building == "Katz"):
                                fitnessScore -=0.4
                            else:
                                fitnessScore += 0.5
                if time!= "3PM":
                        index = lstFind(classTimes, time)
                        if tempTime == classTimes [index +1]:
                            if(tempBuilding == "Katz" and building == "Bloch") or (tempBuilding == "Bloch" and building == "Katz"):
                                fitnessScore -=0.4
                            else:
                                fitnessScore += 0.5
    fitnessScore = round(fitnessScore,2)
   

    
    
    if doubleBookedFlag == False:
        fitnessScore += 0.2
        
    if instructorCount > 4:
        fitnessScore -= 0.5
       
        
    
        
    elif (instructorCount == 2 or instructorCount == 1) and intstructor != "Xu":
        fitnessScore -= 0.4
        
    fitnessScore = round(fitnessScore,2)
    
    for i in range(0,11): #Check course 
        if classes[i].get("course") == course:
            expectedEnrollment = classes[i].get("expected enrollment")
            tempInstructorList = classes[i].get("preferred instructors")
            tempOtherInstructorList = classes[i].get("other instructors")
            break
        
    for i in range(0,9): #fitness for capcity we want to gather the current capacity compare it to whats needed
        if rooms[i].get("building") == building and rooms[i].get("number") == buildingNum:
            capacity = rooms[i].get("capacity")
            break
    expectedEnrollMultThree = expectedEnrollment * 3
    expectedEnrollMultSix = expectedEnrollment * 6
    

    if capacity < expectedEnrollment:
        fitnessScore -= 0.5
        
    elif capacity >= expectedEnrollMultSix:
        fitnessScore -= 0.4

    elif capacity >= expectedEnrollMultThree:
        fitnessScore -= 0.2

    
    else:
        fitnessScore +=0.3
        
    fitnessScore = round(fitnessScore,2)
   
    #instructor prefered course

    if intstructor in tempInstructorList: 
        fitnessScore += 0.5
    elif intstructor in tempOtherInstructorList:
        fitnessScore += 0.2
    else:
        fitnessScore -= 0.1
    fitnessScore = round(fitnessScore,2)
    
    

    return round(fitnessScore,2)


indexClasses = [0,1,2,3,4,5,6,7,8,9,10]#class index we are randomly going to choose from here 

tempList = []
tempDic = {}
fitnessScoresSchedule = []
fitnessScoresOverall = []#overall fitnessScores


for j in range (0,500):#intialize
    tempStorageList.append([0,1,2,3,4,5,6,7,8,9,10])
   
    newGeneration.append([0,1,2,3,4,5,6,7,8,9,10])
    






for i in range (0,500):#this is used to create the first 500 randomly
    
    for j in range (0,11):
        
            if len(indexClasses) != 1:
                classValue = random.randint(0,len(indexClasses) -1)#get a random value from the index
                val = indexClasses[classValue]
                indexClasses.remove(val)
            else:
                val = indexClasses [0]
                indexClasses.remove(val)
                
            

            buildingValue= random.randint(0,8)
            time = random.randint(0,5)
            instructorRand = random.randint(0, 9)
            
            timeRand = random.randint(0,5)

            course = classes[val].get("course")
            #go into the list and clear
            tempDic = {"course" : classes[val].get("course"), "building" : rooms[buildingValue].get("building"), "room" :  rooms[buildingValue].get("number") , "instructor": Faculty [instructorRand] , "time": classTimes [timeRand]}

            if course == "CS101A" : #Place items in order based on course for simplicty and crossover
                tempStorageList [i][0] = tempDic
            if course == "CS101B" :
                tempStorageList [i][1] = tempDic
            if course == "CS191A" :
                tempStorageList [i][2] = tempDic
            if course == "CS191B" :
                tempStorageList [i][3] = tempDic
            if course == "CS201" :
                tempStorageList [i][4] = tempDic
            if course == "CS291" :
                tempStorageList [i][5] = tempDic
            if course == "CS303" :
                tempStorageList [i][6] = tempDic
            if course == "CS304" :
                tempStorageList [i][7] = tempDic
            if course == "CS394" :
                tempStorageList [i][8] = tempDic
            if course == "CS449" :
                tempStorageList [i][9] = tempDic
            if course == "CS451" :
                tempStorageList [i][10] = tempDic
                
                
            
            
    indexClasses = [0,1,2,3,4,5,6,7,8,9,10]
    

            



mutationValue = 100#initial mutation valu
population = 0 #population in beginning used for loop
average = 0 #average fitnessScore
lastAverage = 0 #previous avg from last gen 
improvement = 0 #% improvement
iterations= 0

#First Calculate Fitness and add to list so we can softmax 
while True:
    for i in range(0,500):#outside loop is making sure to do the outer list would be 500
        for j in range (0,11):#counting schedules within
            
            fitnessScoresSchedule.append(fitnessFunction(i,j))#compute the fitnessFunction and add all this too a list 

        sum = AddList(fitnessScoresSchedule)#calculate total fitness Score of scheule
        fitnessScoresOverall.append(sum)#add this sum to fitnessScores Overall
        fitnessScoresSchedule.clear()#clear temp list
    #once outside of loop softmax to get Probability Distribution
    average = averageFitness(fitnessScoresOverall)
   
    
    
     
    if iterations != 0:
        improvement = (average-lastAverage)/(abs(lastAverage)) * 100
      
       
        
        
        if improvement > 0:#make improvement for initial
            mutationValue * 2
        
        if iterations >= 100 and (improvement >= 0 and improvement <=1):
            overallImprovement = (average-orginalAverage)/(abs(orginalAverage))
            maxIndex = findMaxFitness()#get the highest fitnessScore
            file = open("Schedule.txt","w")#output to file
            
            file.write("Best Schedule:")
            file.write("\n")
            for i in range (0,11):
                course = "Course: " + tempStorageList[maxIndex][i].get("course")
                file.write(course)
                file.write("\n")
               
                instructor = "Instructor: " + tempStorageList[maxIndex][i].get("instructor")
                file.write(instructor)
                file.write("\n")
                
                time = "Time: "+ tempStorageList[maxIndex][i].get("time")
                file.write(time)
                file.write("\n")
                building = "Building: " + tempStorageList[maxIndex][i].get("building")
                file.write(building)
                file.write("\n")
                
                room = "Room: "+ tempStorageList[maxIndex][i].get("room")
                file.write(room)
                file.write("\n")
                file.write("\n")
                file.write ("-------------------------------------------------------")
                file.write("\n")
            fitnessScore = "FitnessScore: " + str (fitnessScoresOverall[maxIndex])
            file.write("\n")
            
            file.write (fitnessScore)
            file.write("\n")
            file.write("\n")
            file.close()
            

            
           
           
            softMax()
           
            
        
            break
    else:
        orginalAverage = average

       
    softMax()
   
    while population < 500:#setting up new generation        
        Tournament_Selection(population,mutationValue)
      
        population +=2
       
    tempStorageList = newGeneration
    for i in range(0,500): # reanitialize 500 times to avoid dupes
        
        newGeneration.append([0,1,2,3,4,5,6,7,8,9,10,11])
        
    iterations +=1#reinitialize values
    lastAverage = average
  
    population = 0
    fitnessScoresOverall.clear()
    Parents.clear()
    

    continue

    


print ("Finished Outputed to file")

    
    
    
    

    
            
            
            #one j is done computing compute fitnessScore by puting fitness Values in list. Once computed add all values store in a list
       



'''
To do
selection->crossover until population == 500
once this is done then
tempstorage == newgen
newgen = new gen reintalize

#print(fitnessScoresSchedule)
            
'''
